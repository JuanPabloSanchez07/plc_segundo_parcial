num= float(input("Dame un número"))

if num>0:
  print("El número es positivo")
elif num==0:
  print("El número es cero")
else:
  print("El número es negativo")